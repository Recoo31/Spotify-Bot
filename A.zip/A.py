import requests


proxies = {
   'http': 'http://193.36.61.230:15647',
   'https': 'http://193.36.61.230:15647',
}



a = requests.get('http://ip-api.com/json/', proxies=proxies)

if a.status_code == 200:
    print("200")
else:
    print("sasa")