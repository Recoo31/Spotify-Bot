import requests, random, string
from pystyle import Colors, Colorate
from pystyle import Write, Colors
from keyauth import api
import os
import sys
import os.path
import platform
import hashlib, psutil
from time import sleep
from datetime import datetime
from bs4 import BeautifulSoup as Soup

os.system("cls")
os.system("title Lisans")
print("Wait...")
def getchecksum():
        path = os.path.basename(__file__)
        if not os.path.exists(path):
            path = path[:-2] + "exe"
        md5_hash = hashlib.md5()
        a_file = open(path,"rb")
        content = a_file.read()
        md5_hash.update(content)
        digest = md5_hash.hexdigest()
        return digest

keyauthapp = api(
        name = "Spotify",
        ownerid = "RZCK6vSDM8",
        secret = "4044bfdd9f1a1993f6ee5eb0cea2406c921e48afa2e01dc1a0f4fed9f522134b",
        version = "1.0",
        hash_to_check = getchecksum()
    )

if os.path.exists("login.txt"):
    os.system("cls")
    with open("login.txt", "r") as f:
        for line in f.read().splitlines():
            if ":" in line:
                user = line.split(":")[0]
                password = line.split(":")[-1]
else:

    user = input('Username: ')
    password = input('Password: ')
    os.system("cls")
    os.system("title Spotify Bot")


keyauthapp.login(user,password)
dosya = open("login.txt","w")
dosya.write(user+':'+password)
dosya.close()
os.system("cls")
os.system("title Spotify Bot")

global cevap
cevap = int(input("                        Normal Profil Icın:1                                Artist Icın:2 \n\n >"))
os.system("cls")

class spotify:
    def __init__(self, profile, proxy = None):
        self.session = requests.Session()
        self.profile = profile
        self.proxy = proxy
    
    def register_account(self):
        headers = {
            "Accept": "*/*",
            "Accept-encoding": "gzip, deflate, br",
            "Accept-language": "tr-TR,tr;q=0.9",
            "Content-type": "application/json",
            "Origin": "https://www.spotify.com",
            "Referer": "https://www.spotify.com/",
            "Sec-fetch-dest": "empty",
            "Sec-fetch-mode": "cors",
            "Sec-fetch-site": "same-site",
            "Sec-gpc": "1",
            "User-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36"
        }
        email = ("").join(random.choices(string.ascii_letters + string.digits, k = 17)) + "@hotmail.com"
        password = ("").join(random.choices(string.ascii_letters + string.digits, k = 16))
        year = ("").join(random.choices(string.digits, k = 1))

        proxies = None
        if self.proxy != None:
            proxies = {
                        'http': f'http://{self.proxy}',
                        'https': f'http://{self.proxy}',
                    }
        try:
            us = self.session.get("https://recoo-test.herokuapp.com/api.php", timeout=4)
            self.usi = us.json()['kullanici_adi']
            data = {
	"account_details":{
		"birthdate":"198"+year+"-06-2"+year,
		"consent_flags":{
			"eula_agreed":True,
			"send_email":False,
			"third_party_email":False
		},
		"display_name":self.usi,
		"email_and_password_identifier":{
			"email":email,
			"password":password
		},
		"gender":1
	},
	"callback_uri":"https://www.spotify.com/signup/challenge?locale=tr",
	"client_info":{
		"api_key":"a1e486e2729f46d6bb368d6b2bcda326",
		"app_version":"v2",
		"capabilities":[
			1
		],
		"installation_id":"f84c8a2a-9991-4dd2-a7b4-d74d092997e0",
		"platform":"www"
	},
	"tracking":{
		"creation_flow":"",
		"creation_point":"https://www.spotify.com/tr/",
		"referrer":""
	}
}
            create = self.session.post("https://spclient-ipv6.wg.spotify.com/signup/public/v2/account/create", headers = headers, json = data, proxies = proxies)
            if "login_token" in create.text:
                global username
                c = create.json()['success']
                login_token = c['login_token']
                username = c['username']
                self.username = username
                return login_token
            else:
                return None
        except:
            return False

    def get_csrf_token(self):
        proxies = {
                    'http': f'http://{self.proxy}',
                    'https': f'http://{self.proxy}',
                }
        try:
            r = self.session.get("https://www.spotify.com/uk/signup/?forward_url=https://accounts.spotify.com/en/status&sp_t_counter=1", proxies = proxies)
            return r.text.split('csrfToken":"')[1].split('"')[0]
        except:
            return None
        
    def get_token(self, login_token):
        proxies = {
                    'http': f'http://{self.proxy}',
                    'https': f'http://{self.proxy}',
                }
        headers1 = {
            "Accept": "*/*",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36",
            "Content-Type": "application/x-www-form-urlencoded",
            "X-CSRF-Token": self.get_csrf_token(),
            "Host": "www.spotify.com"
        }
        cook = self.session.post("https://www.spotify.com/api/signup/authenticate", headers = headers1, data = "splot=" + login_token, proxies = proxies)
        spdc = cook.cookies.get('sp_dc')
        headers = {
            "accept": "application/json",
            "Accept-Encoding": "gzip, deflate, br",
            "accept-language": "en",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36",
            "spotify-app-version": "1.1.52.204.ge43bc405",
            "app-platform": "WebPlayer",
            "Host": "open.spotify.com",
            "Referer": "https://open.spotify.com/",
        }
        cookies = {'sp_dc': spdc}
        self.cookies=cookies
        try:
            r = self.session.get(
                "https://open.spotify.com/get_access_token?reason=transport&productType=web_player",
                headers = headers, cookies=self.cookies
            )
            return r.json()["accessToken"]
        except:
            return None
        

    def follow(self):
        if "/user/" in self.profile:
            self.profile = self.profile.split("/user/")[1]
        if "?" in self.profile:
            self.profile = self.profile.split("?")[0]
        login_token = self.register_account()
        if login_token == None:
            return None
        elif login_token == False:
            return None, f""
        auth_token = self.get_token(login_token)
        if auth_token == None:
            return None, "Token Alınamadı"
        headers = {
            "authorization": "Bearer {}".format(auth_token),
            "Host": "api.spotify.com",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:94.0) Gecko/20100101 Firefox/94.0",
            "Accept": "application/json",
            "Accept-Language": "en",
            "Accept-Encoding": "gzip, deflate, br",
            "app-platform": "WebPlayer",
            "spotify-app-version": "1.1.73.305.gbf92e68e",
            "Origin": "https://open.spotify.com",
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-site",
            "Referer": "https://open.spotify.com/",
            "Connection": "keep-alive",
            "Content-Length": "0",
            "TE": "trailers",
        }
        resimhead = {
            "Host": "image-upload.spotify.com",
            "Content-Length": "126757",
            "Accept-Language": "tr",
            "Authorization": "Bearer {}".format(auth_token),
            "Content-Type": "image/jpeg",
            "Accept": "application/json",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.63 Safari/537.36",
            "Origin": "https://open.spotify.com",
            "Sec-Fetch-Site": "same-site",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Dest": "empty",
            "Referer": "https://open.spotify.com/",
            "Accept-Encoding": "gzip, deflate"

        }
        resimhead1 = {
        "accept": "application/json",
        "accept-encoding": "gzip, deflate, br",
        "accept-language": "tr",
        "app-platform": "WebPlayer",
        "Authorization": "Bearer {}".format(auth_token),
        "content-length": "0",
        "origin": "https://open.spotify.com",
        "referer": "https://open.spotify.com/",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-site",
        "sec-gpc": "1",
        "spotify-app-version": "1.1.88.399.g5e8f6880",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36"
        }
        try:
            proxies = {
                    'http': f'http://{self.proxy}',
                    'https': f'http://{self.proxy}',
                    }
            if cevap == 1:
                resim1 = self.session.get("https://picsum.photos/400")
                resim = resim1.content
                r = self.session.post("https://image-upload.spotify.com/v4/user-profile",data=resim, headers=resimhead)
                tokenimiz = r.json()['uploadToken']
                uri = f"https://spclient.wg.spotify.com/identity/v3/profile-image/{self.username}/{tokenimiz}"
                dat = ""
                c = self.session.post(url=uri, data=dat, headers=resimhead1, proxies = proxies)
                reco = "https://api.spotify.com/v1/me/following?type=user&ids="
                putt = self.session.put(
                    reco + self.profile,
                    headers = headers,
                    proxies=proxies,
                    cookies=self.cookies
                )
                if putt.status_code == 204:
                    return True,""
                else:
                    return False, "Retry"
            if cevap == 2:
                reco = "https://api.spotify.com/v1/me/following?type=artist&ids="
                putt = self.session.put(
                    reco + self.profile,
                    headers = headers,
                    proxies=proxies,
                    cookies=self.cookies
                )
                if putt.status_code == 204:
                    return True, ""
                else:
                    return False, "Retry"
        except:
            return False, "Hata"

